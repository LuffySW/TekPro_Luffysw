public interface Koperasi {
    public double loanMonthly(double loanAmount);
}
